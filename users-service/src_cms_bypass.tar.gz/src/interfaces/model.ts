declare type SetNames =
    'user' |
    'address' |
    'logger'

