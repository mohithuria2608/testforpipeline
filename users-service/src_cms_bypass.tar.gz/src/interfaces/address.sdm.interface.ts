
declare namespace IAddressSDMRequest {

    interface ICreateAddress extends ICommonRequest.ISDM {
        // customerRegistrationID: number,
        // address: {
        // }
    }
}
