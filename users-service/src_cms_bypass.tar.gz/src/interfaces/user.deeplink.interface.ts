declare namespace DeeplinkRequest {

    interface CreateDeeplink {
        url: string,
        ios: string,
        // action: string,
        // chatId?: string,
        // userId?: string,
        // emailToken?: string,
    }
}
